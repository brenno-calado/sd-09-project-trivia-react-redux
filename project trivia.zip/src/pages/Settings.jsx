import React from 'react';

class Settings extends React.Component {
  render() {
    return (
      <h1 data-testid="settings-title">
        Configurações
      </h1>
    );
  }
}

export default Settings;
