import React from 'react';
import Header from '../components/Header';

class Gaming extends React.Component {
  render() {
    return (
      <Header />
    );
  }
}

export default Gaming;
