import React from 'react';
import { readFromStorage } from '../services/api';

export default class Ranking extends React.Component {
  constructor(props) {
    super(props);
    this.orderByScore = this.orderByScore.bind(this);
  }

  renderPlayersRankingOrderedByScore(players) {
    return  <table>
        <thead>
          <th>
            Nome:
          </th>
          <th>
            Score:
          </th>
          <th>
            Gravatar:
          </th>
        </thead>
        <tbody>
          { players.map(({ name, score, picture }, index) => (
            <tr key={ index }>
              <td data-testid={ `player-name-${index}` }>
                { name }
              </td>
              <td data-testid={ `player-score-${index}` }>
                { score }
              </td>
              <td>
                <img src={ picture } alt={ `Profile ${name}` } />
              </td>
            </tr>
            ))
          }
        </tbody>
      </table>
  }

  render() {
    const players = readFromStorage('ranking');
    const scores = Object
      .values(
        players
          .map(({ score }) => score)
          .sort((a, b) => b - a),
      );

    return (
      <section>
        <h1 data-testid="ranking-title">
          Ranking
        </h1>
        { this.renderPlayersRankingOrderedByScore(players) }
      </section>
    );
  }
}
