export { default as Home } from './Home';
export { default as Feedback } from './Feedback';
export { default as Gaming } from './Gaming';
export { default as Settings } from './Settings';
export { default as Ranking } from './Ranking';
